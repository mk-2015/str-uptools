import colorama

colorama.init()